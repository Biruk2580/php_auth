<html>
    <head>

    <title>Stuff - Home</title>
    </head>
    <body>
        <h1>This is a stuff page</h1>
    </body>
</html>