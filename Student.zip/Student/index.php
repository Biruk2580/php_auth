<html>
    <head>

    <title>Student - Home</title>
    </head>
    <body>
        <h1>This is a Student page</h1>
    </body>
</html>